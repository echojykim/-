package workshop5;
public class Test05 {
	public static void main(String[] args) {
		String str = "LGcns";
		System.out.printf("%s\n%s\n%s\n%s\n",str.toUpperCase(),str.toLowerCase(),
				str.substring(0, 2).toUpperCase(),str.substring(2, 5).toLowerCase());
	}
}
