--================================================
-- 관리자 계정
--================================================
-- student / student 계정생성
alter session set "_oracle_script" = true;

create user student
identified by student -- 비밀번호 대소문자 구분
default tablespace users;

grant connect, resource to student;

alter user student quota unlimited on users;

--================================================
-- student 계정
--================================================
-- member테이블
create table member(
    id varchar2(20),
    name varchar2(100) not null,
    gender char(1),
    birthday date,
    email varchar2(500) not null,
    point number default 1000,
    reg_date timestamp default systimestamp,
    constraint pk_member_id primary key(id),
    constraint uq_member_email unique(email),
    constraint ck_member_gender check(gender in ('M', 'F'))
);
--drop table member;

insert into
    member
values(
    'honggd', '홍길동', 'M', '1999-09-09', 'honggd@naver.com', default, default
);
insert into
    member
values(
    'gogd', '고길동', 'M', '1980-02-15', 'gogd@naver.com', default, default
);
insert into
    member
values(
    'sinsa', '신사임당', 'F', '1995-05-05', 'sinsa@naver.com', default, default
);
insert into
    member
values(
    'leess', '이순신', null, null, 'leess@naver.com', default, default
);
insert into
    member
values(
    'qwerty', '쿼티', 'F', null, 'qwerty@naver.com', default, default
);

select * from member;
commit;

desc member;
















