package member.model.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import member.model.vo.Member;

/**
 * Dao
 * - Database Access Object
 * - 전달받은 데이터를 바탕으로 database에 질의(DQL/DML)하는 객체
 *
 */
public class MemberDao {
	final String driverClass = "oracle.jdbc.OracleDriver";
	final String url = "jdbc:oracle:thin:@localhost:1521:xe"; // db접속프로토콜@ip:포트:db명(sid)
	final String user = "student";
	final String password = "student";
	
	/**
	 * 
	 * @param member
	 * @return
	 */
	public int insertMember(Member member) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0;
		String sql = "insert into member values(?, ?, ?, ?, ?, default, default)";
		
		try {
			// 1. jdbc driver class 등록
			Class.forName(driverClass);
			// 2. Connection객체 생성 & autoCommit false로 설정
			conn = DriverManager.getConnection(url, user, password);
			conn.setAutoCommit(false);
			// 3. PreparedStatment객체 생성 & 미완성쿼리 값대입
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, member.getId());
			pstmt.setString(2, member.getName());
			pstmt.setString(3, member.getGender());
			pstmt.setDate(4, member.getBirthday());
			pstmt.setString(5, member.getEmail());
			
			// 4. executeUpdate 실행 & 정수형(처리된 행수) 리턴값
			result = pstmt.executeUpdate();
			
			// 5. 트랜잭션
			conn.commit();
			
		} catch (ClassNotFoundException | SQLException e) {			
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			// 6. 자원반납 : 생성의 역순으로 반환
			try {
				pstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		return result;
	}

}
