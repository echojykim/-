package member.view;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Scanner;

import member.controller.MemberController;
import member.model.vo.Member;

/**
 * view클래스
 * - 사용자에게 메뉴노출
 * - 사용자입력값처리
 * - 메뉴선택시 controller의 메소드 호출(요청)
 */
public class MemberMenu {
	
	Scanner sc = new Scanner(System.in);
	MemberController memberController = new MemberController();
	
	public void mainMenu() {
		String menu = "\n"
					+ "***** 회원 정보 관리 *****\n"
					+ "1. 전체조회\n"
					+ "2. 아이디조회\n"
					+ "3. 이름검색\n"
					+ "4. 회원가입\n"
					+ "5. 회원정보변경\n"
					+ "6. 회원탈퇴\n"
					+ "0. 프로그램 종료\n"
					+ "***********************\n"
					+ "선택 : ";
		
		while(true) {
			System.out.print(menu);
			String choice = sc.next();
			Member member = null;
			int result = 0;
			
			switch(choice) {
			case "1" : break;
			case "2" : break;
			case "3" : break;
			case "4" : 
				member = inputMember();
				System.out.println("member@mainMenu = " + member);
				result = memberController.insertMember(member);
				System.out.println(result > 0 ? "> 회원가입 성공!" : "> 회원가입 실패!");
				break;
			case "5" : 
				// 이름, 성별, 생일, 이메일을 한번에 변경할 것.
				break;
			case "6" : break;
			case "0" : return;
			default : System.out.println("잘못 입력하셨습니다.");
			}
		}
		
	}

	/**
	 * 사용자입력값을 받아 member객체를 반환
	 * 
	 */
	private Member inputMember() {
		System.out.println("> 회원정보를 입력하세요");
		System.out.print("아이디 : ");
		String id = sc.next();
		System.out.print("이름 : ");
		String name = sc.next();		
		System.out.print("성별(M/F) : ");
		String gender = String.valueOf(sc.next().toUpperCase().charAt(0)); // "mm" -> "MM" -> 'M'
		System.out.print("생일(19990909) : ");
		String temp = sc.next();
		Date birthday = null;
		// 문자열 -> java.util.Date -> java.sql.Date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		try {
			birthday = new Date(sdf.parse(temp).getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.print("이메일 : ");
		String email = sc.next();
		return new Member(id, name, gender, birthday, email, 0, null);
	}

}







