package com.kh.zoomin.applicant.resume.model.dto;

public enum Status {
	A,B,C;
}
