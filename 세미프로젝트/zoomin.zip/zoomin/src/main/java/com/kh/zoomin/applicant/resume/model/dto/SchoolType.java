package com.kh.zoomin.applicant.resume.model.dto;

public enum SchoolType {
	C2,C3,C4,HI;
}
