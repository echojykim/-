package com.kh.zoomin.recruit.board.exception;

public class RecruitBoardException extends RuntimeException {

	public RecruitBoardException() {
		// TODO Auto-generated constructor stub
	}

	public RecruitBoardException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public RecruitBoardException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	public RecruitBoardException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public RecruitBoardException(String message, Throwable cause, boolean enableSuppression,
			boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

}