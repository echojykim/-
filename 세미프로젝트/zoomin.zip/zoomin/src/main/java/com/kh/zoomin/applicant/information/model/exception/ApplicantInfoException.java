package com.kh.zoomin.applicant.information.model.exception;

public class ApplicantInfoException extends RuntimeException {

	public ApplicantInfoException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ApplicantInfoException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ApplicantInfoException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ApplicantInfoException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ApplicantInfoException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
