package com.kh.zoomin.applicant.resume.model.exception;

public class ResumeException extends RuntimeException {

	public ResumeException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public ResumeException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public ResumeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public ResumeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public ResumeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
}
