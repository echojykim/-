package com.kh.zoomin.applicant.resume.model.dto;

public enum Gender {
	M,F;
}
