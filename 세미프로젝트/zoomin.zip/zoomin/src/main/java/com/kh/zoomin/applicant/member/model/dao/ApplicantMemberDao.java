package com.kh.zoomin.applicant.member.model.dao;

public class ApplicantMemberDao {

}
