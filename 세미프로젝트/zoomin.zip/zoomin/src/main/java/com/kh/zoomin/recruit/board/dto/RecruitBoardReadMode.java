package com.kh.zoomin.recruit.board.dto;

public enum RecruitBoardReadMode {
	NEAR_CLOSURE, MOST_RECENT
}
