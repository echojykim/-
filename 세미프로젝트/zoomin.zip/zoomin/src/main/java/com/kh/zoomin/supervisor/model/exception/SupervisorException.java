package com.kh.zoomin.supervisor.model.exception;

public class SupervisorException extends RuntimeException {

	public SupervisorException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public SupervisorException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
		super(message, cause, enableSuppression, writableStackTrace);
		// TODO Auto-generated constructor stub
	}

	public SupervisorException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public SupervisorException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	public SupervisorException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}
	
	
}
