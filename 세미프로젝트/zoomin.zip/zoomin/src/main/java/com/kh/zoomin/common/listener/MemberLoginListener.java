package com.kh.zoomin.common.listener;

public class MemberLoginListener {

}
