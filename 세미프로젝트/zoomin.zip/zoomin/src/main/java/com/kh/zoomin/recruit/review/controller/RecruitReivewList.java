package com.kh.zoomin.recruit.review.controller;

import java.io.IOException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.kh.zoomin.applicant.companyReviewBoard.model.dto.CompanyReview;
import com.kh.zoomin.applicant.companyReviewBoard.model.service.CompanyReviewService;
import com.kh.zoomin.applicant.member.model.dto.ApplicantMember;
import com.kh.zoomin.applicant.salaryReviewBoard.model.dto.SalaryReview;
import com.kh.zoomin.applicant.salaryReviewBoard.model.service.SalaryReviewService;
import com.kh.zoomin.company.dto.Company;
import com.kh.zoomin.company.service.CompanyService;
import com.kh.zoomin.member.dto.Member;
import com.kh.zoomin.recruit.board.dto.RecruitBoard;
import com.kh.zoomin.recruit.board.service.RecruitBoardService;

/**
 * Servlet implementation class RecruitReivewList
 */
@WebServlet("/recruit/review/recruitReviewList")
public class RecruitReivewList extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private RecruitBoardService rbs = new RecruitBoardService();
	private CompanyReviewService crs = new CompanyReviewService();
	private SalaryReviewService srs = new SalaryReviewService();
	private CompanyService cs = new CompanyService();
	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
				
		String companyNo=request.getParameter("companyNo");
		// 기본적인 페이지 값 설정(없을 때를 대비)
		int currCompanyReivewPage=1;
		int currSalaryReivewPage=1;
		int itemsPerPage=5;
		try {
			// crp = Company-Review-Page 약자
			// 회사 리뷰 페이지에 대한 정보 가져오기를 시도. 없으면 기본값 1으로 진행
			currCompanyReivewPage=Integer.parseInt(request.getParameter("crp"));
		}catch(NumberFormatException e) {}
		try {
			// srp = Salary-Review-Page 약자
			// 연봉 리뷰 페이지에 대한 정보 가져오기를 시도. 없으면 기본값 1으로 진행
			currSalaryReivewPage=Integer.parseInt(request.getParameter("srp"));
		}catch (NumberFormatException e) {}
		
		// 각기 회사리뷰/연봉리뷰를 쿼리해올 범위를 설정.
		int companyStart=(currCompanyReivewPage-1)*itemsPerPage+1;
		int companyEnd=companyStart+itemsPerPage-1;
		
		int salaryStart=(currSalaryReivewPage-1)*itemsPerPage+1;
		int salaryEnd=salaryStart+itemsPerPage-1;
		
		// 리뷰회수용 정보를 담을 parameter 세팅
		Map<String,Object> paramCompany=new HashMap<String, Object>();
		Map<String,Object> paramSalary=new HashMap<String, Object>();
		paramCompany.put("companyStart", companyStart);
		paramCompany.put("companyEnd", companyEnd);
		paramCompany.put("companyNo", companyNo);
		
		paramSalary.put("salaryStart", salaryStart);
		paramSalary.put("salaryEnd", salaryEnd);
		paramSalary.put("companyNo", companyNo);
		
		// 각기 회사와 연봉 리뷰의 내용물 가져오기
		List<CompanyReview> companyReviewResult = crs.findByCompanyNo(paramCompany);
		List<SalaryReview> salaryReviewResult=srs.findByCompanyNo(paramSalary);
		
		// 페이지바 만들기위한 각기 총 리뷰 개수를 회수
		int totalCompanyReviewCount=crs.getTotalContent(companyNo);
		int totalSalaryReviewCount=srs.getTotalContent(companyNo);
		
		// 기본 url과 더불어 혹여 있을 쿼리구문을 추출한 다음에
		String url=request.getRequestURI();
		String queryString=request.getQueryString();
		
		// 신규 쿼리구문을 제작합니다. 
		String companyReviewPagebarHTML=makePagebar(currCompanyReivewPage, itemsPerPage, totalCompanyReviewCount, url,"crp",queryString);
		String salaryReviewPagebarHTML=makePagebar(currSalaryReivewPage, itemsPerPage, totalSalaryReviewCount, url,"srp",queryString);
		
		request.setAttribute("companyReview", companyReviewResult);
		request.setAttribute("companyReviewPagebarHTML", companyReviewPagebarHTML);
		request.setAttribute("salaryReview", salaryReviewResult);
		request.setAttribute("salaryReviewPagebarHTML", salaryReviewPagebarHTML);
		
		// 이후 페이징과는 상관없는 기본적인 회사정보 및 채용정보를 회수
		// 회사정보 회수하기
		Company company = cs.getCompanyByNo(companyNo);
		request.setAttribute("company", company);
		
		// 채용정보 회수하기 
		List<RecruitBoard> recruitBoardList = rbs.loadRecruitBoardByCompanyNo(company.getCompanyNo());
		request.setAttribute("recruitBoardList", recruitBoardList);
		
		
		
		request.getRequestDispatcher("/WEB-INF/views/recruit/review/recruitReviewList.jsp").forward(request, response);
		
	}

	private String makePagebar(int currentPage, int numPerPage, int totalCount, String url,String mode,String originalQueryString) {
		// 새로운 페이지바를 생성하는 코드 페이지바를 제작할 스트링빌더 // 쿼리문을 제작할 스트링 빌더를 선언합니다.
		StringBuilder pagebarBuilder = new StringBuilder();
		StringBuilder queryBuilder=new StringBuilder();
		int totalPages=(int)Math.ceil((double)totalCount/numPerPage);
		int pagebarSize=5;//페이지바에 노출할 번호 개수
		int pagebarStart=(((currentPage-1)/pagebarSize)*pagebarSize)+1;
		int pagebarEnd=pagebarStart+pagebarSize-1;
		
		int pageNo=pagebarStart;
		
		//쿼리구문에 여러개 있는 경우  예 : title=Main_page&action=raw 가 출력됨
		if(originalQueryString==null) {
			// 아예 쿼리문이 없는 경우
			queryBuilder.append("?"+mode+"=");
		}else if(!originalQueryString.contains(mode)) {
			// 쿼리문은 있는데 mode에 일치하는 쿼리가 없는 경우 : 모드 == 회사리뷰(crp)인지, 연봉리뷰(srp)인지
			queryBuilder.append("?"+originalQueryString+"&"+mode+"=");
		}else {
			// 쿼리문도 있고 mode도 이미 있는 경우
			queryBuilder.append("?");
			if(originalQueryString.indexOf("&",originalQueryString.indexOf(mode))==-1) { 
				// mode쿼리의 위치가 끝이면 모드의 문자열을 제외한 문자열을 반환.
				queryBuilder.append(originalQueryString.substring(0, originalQueryString.indexOf("&"+mode)));
			}else {
				// mode의 위치가 끝이 아니라면 -> mode에 해당하는 쿼리를 제거
				String[] splits=originalQueryString.split(mode+"=[0-9]+&");
				String merge = splits[0]+splits[1];
				queryBuilder.append(merge);
			}
			// 최종적으로 쿼리구문에 문자열을 추가.
			queryBuilder.append("&"+mode+"=");
		}
		// 아직 값이 없는 쿼리구문을 출력한다.
		String queryWithoutNumbers=queryBuilder.toString();
		url+=queryWithoutNumbers;
		
		// 여기 이하는 일반적인 페이지바 제작과 같기에 생략.
		if(pageNo==1) {
			
		}else {
			pagebarBuilder.append("<div class='before-after'><a href='"+url+(pageNo-1)+"'>이전</a></div>\n");
		}
		while(pageNo<=pagebarEnd&&pageNo<=totalPages){
			if(pageNo==currentPage) {
				// 현재페이지이면 링크없이 그냥 span을 추가.
				pagebarBuilder.append("<div class='current'><span class='cPage'>"+pageNo+"</span></div>\n");
			}else {
				// 현재페이지가 아니면 해당 페이지를 로드할 링크를 기제한다.
				pagebarBuilder.append("<div class='other-page'><a href='"+url+pageNo+"'>"+pageNo+"</a></div>\n");
			}
			pageNo++;
		}
		if(pageNo>totalPages) {
			//마지막 페이지 블럭인 경우 "다음"을 추가하지 않는다.
			// 위의 증감처리로 인해 pageNo에는 해당 페이지 블럭의 마지막 값+1이 들어있다.
		}else {
			pagebarBuilder.append("<div class='before-after'><a href='"+url+pageNo+"'>다음</a></div>\n");
		}
		
		return pagebarBuilder.toString();
	}
	
}
