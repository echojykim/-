package com.kh.zoomin.applicant.member.model.service;

import com.kh.zoomin.applicant.member.model.dao.ApplicantMemberDao;

public class ApplicantMemberService {

	private ApplicantMemberDao adm = new ApplicantMemberDao();
	
}
