package jdbc.test;

import java.sql.Connection;
import java.sql.Date;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;

/**
	 * DQL
	1. jdbc driver class 등록
	2. Connection객체 생성
	3. PreparedStatment객체 생성
	4. 실행 & ResultSet 리턴받기
	5. ResultSet 처리 
	6. 자원반납 : 생성의 역순으로 반환 

	DML
	1. jdbc driver class 등록
	2. Connection객체 생성 & autoCommit false로 설정
	3. PreparedStatment객체 생성
	4. 실행 & 정수형(처리된 행수) 리턴값
	5. 트랜잭션
	6. 자원반납 : 생성의 역순으로 반환
 *
 */
public class JdbcTest {

	final String driverClass = "oracle.jdbc.OracleDriver";
	final String url = "jdbc:oracle:thin:@localhost:1521:xe"; //db 접속 프로토콜@ip:포트:db명(sid)
	final String user = "student";
	final String password = "student";
	
	public static void main(String[] args) {
		JdbcTest instance = new JdbcTest();
		instance.test1();
		instance.test2("F", "less");
	}
	/**
	 * DML
	 */
	private void test2(String gender, String id) {
		Connection conn = null;
		PreparedStatement pstmt = null;
		int result = 0; //처리행 수 변환 
		String sql = "update member set gender = ? where id = ?"; //전달값을 꼭 대입해야함. 물음표로 불가능
		
		try {
			//1. jdbc driver class등록
			Class.forName(driverClass);
			//2. connection객체 생성 & autoCommit false로 설정
			conn = DriverManager.getConnection(url, user, password);
			conn.setAutoCommit(false); //commit/ rollback처리를 직접하는 설정
			//3. PreparedStatement객체 생성 & 미완성쿼리 값대입 
			pstmt = conn.prepareStatement(sql);
			pstmt.setString(1, gender); // ? -> 'M'
			pstmt.setString(2, id); // ? -> 'less'
			//4. 쿼리 실행 & 정수형(처리된 행의 수) 리턴값 
			result = pstmt.executeUpdate();
			//5. 트랜잭션
			conn.commit();
			System.out.println(result + "행이 수정되었습니다.");
		} catch (ClassNotFoundException | SQLException e) {
			try {
				conn.rollback();
			} catch (SQLException e1) {
				e1.printStackTrace();
			}
			e.printStackTrace();
		} finally {
			//6. 자원반납 
			try {
				pstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
	}

	/**
	 * DQL
	 */
	private void test1() {
		String sql = "select * from member";
		Connection conn = null;
		PreparedStatement pstmt = null;
		ResultSet rset = null;
		try {
			//1. jdbc diver class 등록
			Class.forName(driverClass);
			System.out.println("> 드라이버클래스 등록 완료!");
			//2. connection 객체 생성
			conn = DriverManager.getConnection(url, user, password);
			System.out.println("> DB연결 성공!");
			//3. PreparedStatement 객체 생성
			pstmt = conn.prepareStatement(sql);
			System.out.println("> PreparedStatement객체 생성 성공!");
			//4. 실행 & ResultSet 리턴받기
			rset = pstmt.executeQuery();
			System.out.println("> 실행 및 결과집합 수신 성공!");
			//5. ResultSet 처리 : 
			// next 호출 시 다음 행이 있는 경우, true를 반환, 포인터를 다음행으로 이동시켜둔다.
 			while(rset.next()) {
				// 레코드의 컬럼명으로 접근(컬럼타입)
 				String id = rset.getString("id"); //컬럼명의 대소문자는 구문하지 않는다.
 				String name = rset.getString("name");
 				String gender = rset.getString("gender");
 				Date birthday = rset.getDate("birthday");
 				String email = rset.getString("email");
 				int point = rset.getInt("point");
 				Timestamp regDate = rset.getTimestamp("reg_date");
 				
 				System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%s%n", id, name, gender, birthday, email, point, regDate);
 				
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		} finally {
			//6. 자원반납 : 생성의 역순으로 반환
			try {
				rset.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				pstmt.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			try {
				conn.close();
			} catch (Exception e) {
				e.printStackTrace();
			}
			
			System.out.println("> 자원반납 완료!");
		}

		
	}
}
