package member.run;

import member.view.MemberMenu;

public class MemberRun {

	public static void main(String[] args) {
		new MemberMenu().mainMenu();
		
		System.out.println("===== 이용해주셔서 감사합니다. =====");
	}

}
