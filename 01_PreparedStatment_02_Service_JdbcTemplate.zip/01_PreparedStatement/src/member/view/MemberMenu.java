package member.view;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import member.controller.MemberController;
import member.model.vo.Member;

/**
 * view클래스
 * - 사용자에게 메뉴노출
 * - 사용자입력값처리
 * - 메뉴선택시 controller의 메소드 호출(요청)
 */
public class MemberMenu {
	
	Scanner sc = new Scanner(System.in);
	MemberController memberController = new MemberController();
	SimpleDateFormat simpleRegDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");
	
	public void mainMenu() {
		String menu = "\n"
					+ "***** 회원 정보 관리 *****\n"
					+ "1. 전체조회\n"
					+ "2. 아이디조회\n"
					+ "3. 이름검색\n"
					+ "4. 회원가입\n"
					+ "5. 회원정보변경\n"
					+ "6. 회원탈퇴\n"
					+ "0. 프로그램 종료\n"
					+ "***********************\n"
					+ "선택 : ";
		
		while(true) {
			System.out.print(menu);
			String choice = sc.next();
			Member member = null;
			String id = null;
			String name = null;
			int result = 0;
			List<Member> members = null;
			
			switch(choice) {
			case "1" :
				// select * from member order by reg_date desc
				members = memberController.findAll();
				printMembers(members);
				break;
			case "2" : 
				// select * from member where id = ?
				id = inputMemberId();
				member = memberController.findById(id);
				printMember(member);
				break;
			case "3" : 
				// select * from member where name like '%길동%' 
				name = inputMemberName();
				members = memberController.findByName(name);
				printMembers(members);
				break;
			case "4" : 
				member = inputMember();
				System.out.println("member@mainMenu = " + member);
				result = memberController.insertMember(member);
				System.out.println(result > 0 ? "> 회원가입 성공!" : "> 회원가입 실패!");
				break;
			case "5":
				// 이름, 성별, 생일, 이메일을 한번에 변경할 것.
				// update member set name = ?, gender = ?, birthday = ?, email = ? where id = ? 
				member = updateMember();
				result = memberController.updateMember(member);
				System.out.println(result > 0 ? "> 회원정보 수정 성공!" : "> 회원정보 수정 실패!"); 
			case "6":
				id = inputMemberId(); 
				result = memberController.deleteMember(id);
				System.out.println(result > 0 ? "> 회원탈퇴 성공!" : "> 회원탈퇴 실패!");
				break;
			case "0" : return;
			default : System.out.println("잘못 입력하셨습니다.");
			}
		}
		
	}
	
	private String inputMemberName() {
		System.out.println("> 검색할 이름을 입력하세요.");
		System.out.print("이름 : ");
		return sc.next();
	}

	/**
	 * 0 ~ 1건이 조회될때, 실제조회결과가 0건이면, null를 리턴.
	 * @param member
	 */
	private void printMember(Member member) {
		if(member == null) {
			System.out.println("> 조회된 결과가 없습니다.");
		}
		else {
			System.out.println("---------------------------------");
			System.out.printf("%-10s : %s%n", "id", member.getId());
			System.out.printf("%-10s : %s%n", "name", member.getName());
			System.out.printf("%-10s : %s%n", "gender", member.getGender());
			System.out.printf("%-10s : %s%n", "birthday", member.getBirthday());
			System.out.printf("%-10s : %s%n", "email", member.getEmail());
			System.out.printf("%-10s : %s%n", "point", member.getPoint());
			System.out.printf("%-10s : %s%n", "regDate", simpleRegDateFormat.format(member.getRegDate()));
			System.out.println("---------------------------------");
		}	
	}
	
	/**
	 * 0 ~ n건이 조회될때, 실제조회결과가 0건이면, 빈 ArrayList객체를 반환.
	 * @param members
	 */
	private void printMembers(List<Member> members) {
		if(members == null || members.isEmpty()) {
			System.out.println("> 조회된 결과가 없습니다.");
		}
		else {
			System.out.println("-----------------------------------------------------------------");
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%S\t%n",
							"id", "name", "gender", "birthday", "email", "point", "regDate");
			System.out.println("-----------------------------------------------------------------");
			for(Member member : members) {
				System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%S\t%n",
							  member.getId(),
							  member.getName(),
							  member.getGender(),
							  member.getBirthday(),
							  member.getEmail(),
							  member.getPoint(),								  
							  simpleRegDateFormat.format(member.getRegDate())								  
						);
			}
			System.out.println("-----------------------------------------------------------------");
		}
		
	}

	/**
	 * 회원정보 수정
	 * - 이름, 성별, 생일, 이메일
	 */
	private Member updateMember() {
		System.out.println("> 수정할 회원 아이디를 입력하세요.");
		System.out.print("아이디 : ");
		String id = sc.next();
		System.out.println("> 수정할 회원 정보를 입력하세요.");
		System.out.print("이름 : ");
		String name = sc.next();		
		System.out.print("성별(M/F) : ");
		String gender = String.valueOf(sc.next().toUpperCase().charAt(0)); // "mm" -> "MM" -> 'M'
		System.out.print("생일(19990909) : ");
		String temp = sc.next();
		Date birthday = null;
		// 문자열 -> java.util.Date -> java.sql.Date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		try {
			birthday = new Date(sdf.parse(temp).getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.print("이메일 : ");
		String email = sc.next();
		return new Member(id, name, gender, birthday, email, 0, null);
	}
	
	private String inputMemberId() {
		System.out.print("> 아이디를 입력하세요 : ");
		return sc.next();
	}


	/**
	 * 사용자입력값을 받아 member객체를 반환
	 * 
	 */
	private Member inputMember() {
		System.out.println("> 회원정보를 입력하세요");
		System.out.print("아이디 : ");
		String id = sc.next();
		System.out.print("이름 : ");
		String name = sc.next();		
		System.out.print("성별(M/F) : ");
		String gender = String.valueOf(sc.next().toUpperCase().charAt(0)); // "mm" -> "MM" -> 'M'
		System.out.print("생일(19990909) : ");
		String temp = sc.next();
		Date birthday = null;
		// 문자열 -> java.util.Date -> java.sql.Date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		try {
			birthday = new Date(sdf.parse(temp).getTime());
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.print("이메일 : ");
		String email = sc.next();
		return new Member(id, name, gender, birthday, email, 0, null);
	}

}







