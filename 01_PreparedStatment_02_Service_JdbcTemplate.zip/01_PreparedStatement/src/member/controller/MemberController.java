package member.controller;

import java.util.List;

import member.model.dao.MemberDao;
import member.model.vo.Member;

/**
 * Controller클래스
 * - MVC패턴의 가장 중추역할
 * - view로부터 요청을 받아 dao로 다시 요청을 전달
 * - dao의 처리결과값을 받아 view로 리턴처리(응답)
 * 
 *
 */
public class MemberController {
	
	private MemberDao memberDao = new MemberDao();

	public int insertMember(Member member) {
		int result = memberDao.insertMember(member);
		return result;
	}
	
	public int updateMember(Member member) {
		return memberDao.updateMember(member);
	}
	
	public int deleteMember(String id) {
		return memberDao.deleteMember(id);
	}

	public List<Member> findAll() {
		List<Member> members = memberDao.findAll();
		return members;
	}

	public Member findById(String id) {
		Member member = memberDao.findById(id);
		return member;
	}

	public List<Member> findByName(String name) {
		List<Member> members = memberDao.findByName(name);
		return members;
	}
	



}
