package member.view;

import java.sql.Date;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Scanner;

import member.controller.MemberController;
import member.model.vo.Member;

public class MemberMenu {
	
	private MemberController memberController = new MemberController();
	private Scanner sc = new Scanner(System.in);
	private SimpleDateFormat simpleRegDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm");

	public void mainMenu() {
		String menu = "\n"
					+ "***** 회원 정보 관리2 *****\n"
					+ "1. 전체조회\n"
					+ "2. 아이디조회\n"
					+ "3. 이름검색\n"
					+ "4. 회원가입\n"
					+ "5. 회원정보변경\n"
					+ "6. 회원탈퇴\n"
					+ "0. 프로그램 종료\n"
					+ "***********************\n"
					+ "선택 : ";
		while(true) {
			System.out.print(menu);
			String choice = sc.next();
			Member member = null;
			int result = 0;
			List<Member> members = null;
			
			switch (choice) {
			case "1": 
				// select * from member
				members = memberController.findAll();
				printMembers(members);
				break;
			case "2": break;
			case "3": break;
			case "4":
				// insert into member values(?, ?, ?, ?, ?, ?, ?)
				member = inputMember();
				result = memberController.insertMember(member);
				displayResult(result, "회원가입");
				break;
			case "5": break;
			case "6": break;
			case "0": return;
			default:
				System.out.println("잘못 입력하셨습니다.");
			}
			
		}
		
	}
	
	/**
	 * 0 ~ n건이 조회될때, 실제조회결과가 0건이면, 빈 ArrayList객체를 반환.
	 * @param members
	 */
	private void printMembers(List<Member> members) {
		if(members == null || members.isEmpty()) {
			System.out.println("> 조회된 결과가 없습니다.");
		}
		else {
			System.out.println("-----------------------------------------------------------------");
			System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%S\t%n",
							"id", "name", "gender", "birthday", "email", "point", "regDate");
			System.out.println("-----------------------------------------------------------------");
			for(Member member : members) {
				System.out.printf("%s\t%s\t%s\t%s\t%s\t%s\t%S\t%n",
							  member.getId(),
							  member.getName(),
							  member.getGender(),
							  member.getBirthday(),
							  member.getEmail(),
							  member.getPoint(),								  
							  simpleRegDateFormat.format(member.getRegDate())								  
						);
			}
			System.out.println("-----------------------------------------------------------------");
		}
		
	}

	/**
	 * 아이디, 이름, 성별, 생일, 이메일
	 * (포인트, 가입일 - 기본값처리)
	 * @return
	 */
	private Member inputMember() {
		Member member = new Member();
		System.out.println("> 회원정보를 입력하세요");
		System.out.print("아이디 : ");
		member.setId(sc.next());
		System.out.print("이름 : ");
		member.setName(sc.next());		
		System.out.print("성별(M/F) : ");
		member.setGender(String.valueOf(sc.next().toUpperCase().charAt(0))); 
		System.out.print("생일(19990909) : ");
		String temp = sc.next();
		// 문자열 -> java.util.Date -> java.sql.Date
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
		try {
			member.setBirthday(new Date(sdf.parse(temp).getTime()));
		} catch (ParseException e) {
			e.printStackTrace();
		}
		System.out.print("이메일 : ");
		member.setEmail(sc.next());
		return member;
	}

	/**
	 * DML처리결과 화면 출력 메소드
	 * @param result
	 * @param string
	 */
	private void displayResult(int result, String type) {
		if(result > 0)
			System.out.printf("> %s 성공!%n", type);
		else
			System.out.printf("> %s 실패!%n", type);
	}

}



