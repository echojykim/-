package member.model.service;

import static member.common.JdbcTemplate.close;
import static member.common.JdbcTemplate.commit;
import static member.common.JdbcTemplate.getConnection;
import static member.common.JdbcTemplate.rollback;

import java.sql.Connection;
import java.util.List;

import member.model.dao.MemberDao;
import member.model.vo.Member;

/**
 * Service클래스
 * - 업무로직 business logic 수행
 * 
 * ------------------ SERVICE 시작 ----------------------
 * 1. jdbc driver class 등록 
 * 2. Connection객체 생성 & setAutoCommit(false)
 * ------------------ DAO 시작 ----------------------
 * 3. PreparedStatment객체 생성 & 미완성쿼리 값대입
 * 4. 실행 & 결과값받기 (ResultSet, int)
 * 5. 자원반납(pstmt, rset)
 * ------------------ DAO 끝 ---------------------- 
 * 6. 트랜잭션처리 
 * 7. 자원반납(conn)
 * ------------------ SERVICE 끝 ----------------------
 * 
 *
 */
public class MemberService {

	private MemberDao memberDao = new MemberDao();
	
	/**
	 * DML
	 * 
	 * @param member
	 * @return
	 */
	public int insertMember(Member member) {
		int result = 0;
		Connection conn = null;
		try {
			conn = getConnection();
			result = memberDao.insertMember(conn, member);
			commit(conn);
		} catch(Exception e) {
			rollback(conn);
		} finally {
			close(conn);
		}
		return result;
	}

	/**
	 * DQL
	 * 
	 * @return
	 */
	public List<Member> findAll() {
		Connection conn = getConnection();
		List<Member> members = memberDao.findAll(conn);
		close(conn);
		return members;
	}
	
	
}
