package kh.java.project.member;

public class Run {

	public static void main(String[] args) {
		new MemberView().mainMenu();
	}

}
